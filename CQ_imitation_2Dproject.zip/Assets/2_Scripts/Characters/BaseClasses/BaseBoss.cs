﻿using System.Collections.Generic;

// 베이스 보스(적 진영) 클래스.
// 보스의 특수 공격은 각각의 보스 클래스에 구현.

public abstract class BaseBoss : EnemyController, IUsableSkill
{
    protected string bossName;
    protected Queue<int> SkillQueue;
    private bool isCasting = false;
    private bool firstCasting;
    private bool secondCasting;
    private bool thirdCasting;

    protected override void Awake()
    {
        Init();
        SkillQueue = new Queue<int>();
        stateMoveForward = new StateMoveForward(this);
        stateCombat = new StateCombat(this);
        stateSkillCasting = new StateSkillCasting(this);
        firstCasting = true;
        secondCasting = true;
        thirdCasting = true;

        SetState(stateMoveForward);
    }

    // 보스의 피격 로직에 남은 HP량에 따른 특수 공격 로직 추가
    // 체력이 적을 때 발동하는 공격이 좀 더 강한 위력을 가짐
    public override void TakeDamage(int damage)
    {
        CurHealthPoint -= damage;

        float curHpRate = CurHealthPoint / (float)status.HealthPoint;
        if (curHpRate <= 0.8 && firstCasting)
        {
            RegistSkillQueue(1);
            firstCasting = false;
        }

        else if (curHpRate <= 0.5 && secondCasting)
        {
            RegistSkillQueue(2);
            secondCasting = false;
        }

        else if (curHpRate <= 0.2 && thirdCasting)
        {
            RegistSkillQueue(3);
            thirdCasting = false;
        }

        else if (CurHealthPoint <= 0)
        {
            Died();
        }
        EnemyHpUpdate(CurHealthPoint, status.HealthPoint);
    }

    public void RegistSkillQueue(int chain)
    {
        SkillQueue.Enqueue(chain);
    }

    public bool IsWaitingSkill()
    {
        if (SkillQueue.Count > 0)
            return true;
        else
            return false;
    }

    public void CastSkillQueue()
    {
        isCasting = true;
        SkillLogic(SkillQueue.Dequeue());
        isCasting = false;
    }

    public IUsableSkill GetClass()
    {
        return this;
    }

    public bool IsCasting()
    {
        return isCasting;
    }

    public abstract void SkillLogic(int chain);
}
