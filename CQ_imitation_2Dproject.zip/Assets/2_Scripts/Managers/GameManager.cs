﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : SingletonePattern <GameManager>
{
    void Start()
    {
        
    }
}
